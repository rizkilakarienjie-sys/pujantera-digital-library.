# DigiTour Jambi

Website statis untuk proyek Pusat Informasi Digital Pariwisata Daerah.

## Publikasi melalui GitHub Pages

1. Buat akun atau masuk ke https://github.com
2. Buat repository baru bernama `digitour-jambi`.
3. Pilih **Public**, lalu buat repository.
4. Klik **Add file → Upload files**.
5. Unggah `index.html` dari folder ini, lalu klik **Commit changes**.
6. Buka **Settings → Pages**.
7. Pada **Build and deployment**, pilih **Deploy from a branch**.
8. Pilih branch `main`, folder `/(root)`, lalu klik **Save**.
9. Tunggu proses publikasi selesai. URL website biasanya:
   `https://USERNAME.github.io/digitour-jambi/`

Ganti `USERNAME` dengan username GitHub milik Anda.

## Catatan
- Website ini adalah prototipe statis dengan data contoh.
- Belum ada login, database, dashboard admin, atau unggah dokumen.
- Periksa dan lengkapi sumber referensi, foto berlisensi, alamat, jam operasional, serta informasi terkini sebelum dipakai sebagai sumber publik.
